Il progetto è stato realizzato su PostgreSQL versione 5.7.

Per far funzionare il Database, compilare i file nel seguente ordine:
1. Definizioni
2. Attributi Calcolati (Trigger)
3. Vincoli
4. Popolamento

Tutti gli altri file possono essere compilati dopo questi quattro in ordine arbitrario